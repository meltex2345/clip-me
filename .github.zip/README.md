# Clip Me

Free, browser-based video clipping. The public GitHub Pages version runs in your browser and supports local video uploads, preview, and WebM export.

## Publish with GitHub Pages

Keep the folder structure intact when adding these files to the root of the `clip-me` repository. The workflow at `.github/workflows/pages.yml` deploys the site after it is pushed to the `main` branch. In repository **Settings → Pages**, choose **GitHub Actions** as the source.

## Optional local server

For importing direct public video file URLs on your own computer, install Node.js 18 or newer and run `start-server.bat`. Then open http://127.0.0.1:4173. Only direct public MP4, WebM, MOV, or Ogg video file links work; YouTube watch pages are not supported. Imported files are stored in `server/imports`.
