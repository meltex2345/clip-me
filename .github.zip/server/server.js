const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const dns = require('node:dns/promises');
const { isIP } = require('node:net');

const ROOT = path.resolve(__dirname, '..');
const UPLOADS = path.join(__dirname, 'imports');
const PORT = Number(process.env.PORT || 4173);
fs.mkdirSync(UPLOADS, { recursive: true });

function privateAddress(ip) {
  if (ip.includes(':')) return ip === '::1' || ip.startsWith('fc') || ip.startsWith('fd') || ip.startsWith('fe80:') || ip === '::';
  const n = ip.split('.').map(Number);
  return n[0] === 10 || n[0] === 127 || n[0] === 0 || n[0] >= 224 || (n[0] === 169 && n[1] === 254) || (n[0] === 172 && n[1] >= 16 && n[1] <= 31) || (n[0] === 192 && n[1] === 168);
}
async function validateUrl(raw) {
  let u; try { u = new URL(raw); } catch { throw new Error('Enter a valid video URL.'); }
  if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password) throw new Error('Only public HTTP or HTTPS links are supported.');
  const host = u.hostname.replace(/^\[|\]$/g, '');
  const addresses = isIP(host) ? [{ address: host }] : await dns.lookup(host, { all: true });
  if (!addresses.length || addresses.some(x => privateAddress(x.address))) throw new Error('That link does not point to a public internet address.');
  return u;
}
async function readBody(req) { let data = ''; for await (const part of req) { data += part; if (data.length > 8192) throw new Error('Request too large.'); } return JSON.parse(data); }
function send(res, status, body) { res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'access-control-allow-origin': 'null' }); res.end(JSON.stringify(body)); }
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (req.method === 'OPTIONS') { res.writeHead(204, { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'POST, OPTIONS', 'access-control-allow-headers': 'content-type' }); return res.end(); }
    if (req.method === 'POST' && url.pathname === '/api/import') {
      const body = await readBody(req); let target = await validateUrl(body.url); let response;
      for (let i = 0; i < 6; i++) { response = await fetch(target, { redirect: 'manual', signal: AbortSignal.timeout(30000), headers: { 'user-agent': 'Clip Me/1.0 video link importer' } }); if (![301,302,303,307,308].includes(response.status)) break; const location = response.headers.get('location'); if (!location) throw new Error('The video host returned an invalid redirect.'); target = await validateUrl(new URL(location, target).href); }
      if (!response || !response.ok) throw new Error(`Could not fetch that link (${response?.status || 'request failed'}). Use a direct, public video file URL.`);
      const type = (response.headers.get('content-type') || '').split(';')[0].toLowerCase();
      if (!type.startsWith('video/') && !/\.(mp4|webm|mov|m4v|ogv)(?:$|[?#])/i.test(target.href)) throw new Error('This looks like a webpage, not a direct video file. Paste a public MP4, WebM, or MOV link.');
      if (Number(response.headers.get('content-length') || 0) > 500*1024*1024) throw new Error('Videos must be 500 MB or smaller.');
      const ext = ({'video/mp4':'.mp4','video/webm':'.webm','video/quicktime':'.mov','video/ogg':'.ogv'})[type] || path.extname(new URL(target).pathname).slice(0,8) || '.video';
      const name = `import-${Date.now()}${ext}`, dest = path.join(UPLOADS,name); let total = 0; const file = fs.createWriteStream(dest);
      try { for await (const chunk of response.body) { total += chunk.length; if(total>500*1024*1024) throw new Error('Videos must be 500 MB or smaller.'); if(!file.write(chunk)) await new Promise((resolve,reject)=>{file.once('drain',resolve);file.once('error',reject)}); } await new Promise((resolve,reject)=>file.end(err=>err?reject(err):resolve())); } catch(err) { file.destroy(); fs.rmSync(dest,{force:true}); throw err; }
      res.writeHead(200, {'content-type':type.startsWith('video/')?type:'application/octet-stream','content-length':total,'content-disposition':`attachment; filename="${name}"`,'access-control-allow-origin':'null'}); return fs.createReadStream(dest).pipe(res);
    }
    if (req.method === 'GET' && url.pathname === '/') { res.writeHead(200, {'content-type':'text/html; charset=utf-8'}); return fs.createReadStream(path.join(ROOT,'index.html')).pipe(res); }
    if (req.method === 'GET' && url.pathname.startsWith('/imports/')) { const name=path.basename(url.pathname), file=path.join(UPLOADS,name); if(!fs.existsSync(file)){res.writeHead(404);return res.end('Not found');} res.writeHead(200,{'content-type':({'.mp4':'video/mp4','.webm':'video/webm','.mov':'video/quicktime','.ogv':'video/ogg'})[path.extname(file)]||'application/octet-stream','content-length':fs.statSync(file).size}); return fs.createReadStream(file).pipe(res); }
    res.writeHead(404); res.end('Not found');
  } catch(err) { if(!res.headersSent) send(res,400,{error:err.message||'Import failed.'}); else res.destroy(err); }
});
server.listen(PORT,'127.0.0.1',()=>console.log(`Clip Me is ready at http://127.0.0.1:${PORT}`));
